# MEMOIRE — Le Coffre des Arcanes (ex-Arcane Vault) + Clicker

> Handoff pour le Claude qui continue le dev. À lire en premier, à mettre à jour à la fin de chaque étape.
> Dernière mise à jour : 2026-11-16. Langue de travail : français. Utilisateur : MJ de JDR D&D, non-dev, colle les blocs à la main.

## 0. Points à trancher AVANT de coder (info manquante → demander)
1. **Chemin de déploiement incohérent** : `CLAUDE.md` / `manifest.json` disent `/mcc/arcane_vault/` ; `script.js` enregistre le SW sur `/coffre_des_arcanes/sw.js` ; l'URL GitHub Pages donnée pour le clicker est `https://moulecake.github.io/coffre_des_arcanes/`. Le dépôt actuel est probablement `coffre_des_arcanes` → `manifest.json` (`start_url`, `scope`) et le `<link rel=manifest>` sont sans doute à corriger. **Vérifier avec l'utilisateur.**
2. `sw.js` actuel (cache `arcane-vault-cache-v1`) ne met en cache que `index.html, style.css, script.js, data.js` (chemins relatifs) → pas de clicker, pas de chemins absolus.
3. `manifest.json` n'a qu'une icône 32×32 : Android exige 192 et 512 (+ `purpose`). L'installation Android a déjà échoué pour ça.
4. Patch `claimClickerFragments` (voir §5) donné à l'utilisateur, **application non confirmée**.
5. Sprint 4 : valeur « End Game » (15–30 clés/jour passif, ou 8–15) à confirmer.

## 1. Fichiers du projet
| Fichier | Rôle | Règle |
|---|---|---|
| `index.html` | Structure + Firebase module (SDK via CDN) + sidebar, modales, footer légal | blocs ciblés seulement |
| `style.css` | Design global | idem |
| `script.js` (v2.0.1) | Logique Coffre (~1300 l.) | idem |
| `data.js` | 464 objets `const loots = ["Nom\|Lien\|Type\|Rareté", ...]` | **NE JAMAIS LIRE NI MODIFIER** |
| `manifest.json`, `sw.js` | PWA | chemins absolus, cf. §0 |
| `clicker/` | `clicker.html, clicker.css, clicker-core.js, clicker-passives.js, clicker-spells.js, MEMOIRE.md` (mémoire spécifique clicker, plus détaillée) | 5 fichiers Coffre jamais fusionnés ; clicker séparé |

## 2. Règles de l'utilisateur (non négociables)
- Persona : UI Engineer / Web Designer vibe 2026 — dark, bento, glassmorphism, micro-interactions.
- **Ultra concis.** Ne jamais réécrire un fichier entier : fonctions modifiées / sélecteurs / blocs HTML ciblés, avec « remplace X par Y ».
- Ne rien supprimer du code existant sans le dire ; l'utilisateur a déjà dû rappeler cela.
- Pas de faux objets de test sauf demande.
- Raretés STRICTEMENT majuscules : `C PC R TR L A`. Taux : C40 / PC25 / R20 / TR8 / L5 / A2.
- Info clé manquante → pause et question (une seule, courte).
- Lire ce fichier au début, le mettre à jour à la fin de chaque étape.
- **Refusé et à refuser** : fabriquer un code de profil/triche (`AV1-…`) avec des objets. Proposer l'outil MJ à la place.

## 3. Coffre — fonctionnement
- Constantes (`script.js`) : `CURRENT_VERSION="2.0.1"`, `MAX_KEYS=3` (dépassable via fragments), `REGEN_MS=4h`, `FRAGS_PER_KEY=5`, `LSKEY='arcane-vault'`.
- Versioning : changement majeur = reset total ; mineur = reset clés.
- État : `{version, pseudo, keys, lastRegen, inventory{lootStr:count}, fragments, activeTrade, lastTradeNonce, processedNonces, clickerClaimed, mjAdded}`. Clé d'inventaire = ligne complète de loot ; la rareté affichée vient de `actualRarity` (cascade de repli quand une rareté est vide — a causé « PC affiché R »).
- Tirage : rareté d'abord (table ci-dessus), puis objet au hasard dans cette rareté.
- Profil : pseudo persistant. Export/import `AV1-` + Base64 (`btoa(unescape(encodeURIComponent(json)))`), anti-rollback via `lastTradeNonce`. Inspection par code (lecture seule) séparée du bouton d'écrasement.
- Troc asynchrone `AV-TRD-…` en 2 étapes : donneur perd A → receveur choisit B et reçoit un code `B-XXXX` → donneur valide et reçoit B. Annuler = perte des deux (voulu). Sélecteur de troc : `c>=1`, `refreshTradeSelect()` appelé dans `openSidebar`.
- Sidebar : accordéon « 🔮 Pactes & Grimoires » avec verrouillage anti-softlock ; `.locked` ne doit pas bloquer le re-clic sur l'en-tête ; le cadenas ne doit **jamais** ouvrir le MJ (garde `sidebar.contains(e.target)`) ; sidebar `overflow-y:auto` avec scrollbar discrète.
- MJ : code **8416** (5 clics rapides sur logo / bouton inventaire) → reset clés, forcer prochain drop L, `mjAddItem` (utiliser `parseInt(raw.trim())`, comparer à `display.length`).
- Audio Web Audio procédural (`playClickSound`, `playRevealSound`) + `navigator.vibrate`.
- Footer légal micro + modale unique (mentions, confidentialité, accessibilité).

## 4. Firebase
- Projet `coffre-des-arcanes`, Google Auth. Globals exposés par le module de `index.html` : `window.auth, db, doc, setDoc, getDoc, collection, getDocs, onAuthStateChanged, signInWithPopup, signOut`.
- Firestore `players/{uid}` = `{pseudo, state:{…}, clicker:{json, earned, ts}, lastUpdated}` ; écritures `setDoc(..., {merge:true})`. Classement : `getDocs(collection(db,'players'))` (`openLeaderboardModal`).
- Fonctions cloud côté Coffre : `saveState`, `loadState`, `saveGameDataToCloud`, `loadGameDataFromCloud(uid)`.
- ⚠ `saveState()` écrit aussi dans le cloud à chaque appel → risque quota ; envisager debounce.
- Règles de sécurité Firestore : non vues, à vérifier (chaque joueur n'écrit que son doc).

## 5. Pont Coffre ⇄ Clicker (fragments de clés)
- Le clicker gagne des fragments (`S.fr.earned` cumulé) ; le Coffre calcule `d = earned − state.clickerClaimed`, ajoute à `state.fragments`, convertit 5 → 1 clé, sauve, toast. **Idempotent.**
- Patch à coller dans `script.js` : fonction `claimClickerFragments(cloudEarned)` (lit `localStorage['coffre-clicker'].fr.earned`), appelée en fin de `loadState()`, dans `loadGameDataFromCloud` (`docSnap.data().clicker?.earned`) et sur `pageshow`.
- Équilibrage actif : fenêtre d'effort 300 s (`FR_SEC`), 9 fragments/jour (`FR_DAY`) ; 10–15 min de jeu intense ≈ 1–2 fragments.

## 6. Clicker — architecture (détail dans `clicker/MEMOIRE.md`)
- `clicker-core.js` (~22 Ko) : état `S`, boucle, Voile (orbe SVG liquide/réseau), Grimoire double page (jauge de page `S.g`), Éther/Sagesse, fragments (`fragTick`), hors-ligne `away(sec)` (`M("offlineCap",8)` h), cloud (`cloudSave(force)`, `cloudLoad` : `S.seen` le plus récent gagne, `earned` = max), curseur custom (enfant direct de `<body>`), sons seulement sur action utilisateur.
- `clicker-passives.js` : 6 bâtiments (Ancrage Runique, Pylône de Stase, Boussole Arcanique → Voile/Éther ; Lutin Scribe, Bougie d'Invocation, Homoncule Liseur → Grimoire/Sagesse), coût `base×1.15^n`, paliers ×2 à 10/25/50/100 ; `Passives.calc()` → `{clickV, ethPS, pagesPS, sgPage, sgPS, pageClick, rare}`.
- `clicker-spells.js` : 8 écoles (evo enc ill nec abj div tra con), 32 sorts, Amphithéâtre (75/750/7500/75000 Sg ; 30 s/5 min/30 min/3 h), decks (max 8), Gold Sink (seuil 15 s ; payer 50+90 s Éther ou 20+90 s Sg, sinon pénalité 30 s), hooks `M(key, def)` : click, ether, passive, pylon, famil, scribe, pagesFlat, sg, rare, redX, ethCost, sgCost, buffDur, offlineCap, offlineSg, cps, cd, study.
- Unités : nL→EL (`fE`), suffixes Sagesse (`fN`). Timers = timestamps absolus. LocalStorage `coffre-clicker`.
- UI : `clicker.html` (retour `../index.html` « ← Retour au Coffre », bouton « 🗂 Decks », puces `#eth #fr #sg`, `#orb.veil`, `#tome.book`), modales pick/dk/gate z-index 22/23.

## 7. Roadmap
### Sprint 4 — micro-fragments passifs (défauts validés par l'utilisateur, **non codé**)
- Flux passif lié à l'Éther/s (nL/s) du Voile, interpolation : 1e1 → 0,1 clé/j ; 1e6 → 1 ; 1e9 → 5 ; 1e12 → 12 ; 1e15 → 22.
- `S.fr.micro` (0–99), 100 micro = 1 fragment ; `S.fr.pday` plafond passif 25 clés/jour, **séparé** des 9 fragments actifs/jour (inchangés).
- Nouveau hook `frag` (multiplicateur) sur Alchimie Mineure, Philosophie de la Matière, Vision du Passé (hors-ligne). Le Grimoire ne produit rien directement.
- Hors-ligne plafonné par `offlineCap` (8 h, 10 h avec Glyphe de Warding), horloge appareil.
- Visuel : fiole SVG (grains du réseau → fiole, 100/100 brille → +1 fragment) ; clé SVG à 5 segments = `(state.fragments + non réclamés) % 5` en lecture seule depuis `players/{uid}.state.fragments` + `clickerClaimed` (repli `earned % 5`) ; à 5/5 la clé pulse puis vole avec traînée vers « ← Retour au Coffre » (purement visuel) et retombe à 0/5. Particules ≤ ~6/s. Aucune écriture par tick (sync à chaque fragment entier).
- Noter le sprint dans `clicker/MEMOIRE.md`.
### Étape 5 (restée ouverte)
Lien depuis `index.html` vers `clicker/clicker.html`, ajouter les fichiers clicker au cache de `sw.js` (chemins absolus), équilibrage global, popover de sort sur mobile, polish ; confirmer visuellement UI-B / UI-C (UI-A validé « Super beau »).

## 8. Pièges connus (ne pas répéter)
- `</script>` dans un commentaire JS casse la page.
- Backticks imbriqués → perte de coloration de l'éditeur : concaténer.
- `backdrop-filter` crée un bloc contenant pour `position:fixed` : éléments flottants (curseur) en enfants directs de `<body>`.
- Bug de sélecteur `.gear` : le bouton Decks ouvrait le picker (`.gear[data-p]`).
- Boucle de sons en auto-farm : sons uniquement sur geste utilisateur.
- Pages spéciales du Grimoire instables → système de jauge de page.
- Stale `activeTrade` → faux « contrat déjà en cours » : nettoyer.
- Tests Node : stubber les éléments DOM et définir `T`.

## 9. Historique des décisions
Étapes B (profil), C (code partage Base64), D (troc), accordéon Pactes, refonte troc 2 temps, légal, PWA, Firebase, clicker étapes 1–4 + correctifs, Sprint 3 UI-A/B/C (Voile, Grimoire double page, glyphes, Web Audio). Voir `clicker/MEMOIRE.md` pour le détail clicker.

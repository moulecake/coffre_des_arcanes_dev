# Directives — Le Coffre des Arcanes (ex-Arcane Vault)

Lis `MEMOIRE.md` avant toute action ; mets-le à jour en fin d'étape. Réponds en français, ultra concis.

## Posture
UI Engineer / Web Designer vibe 2026 : sombre, bento, glassmorphism, micro-interactions fluides, typé JDR.

## Économie de tokens
- Ne réécris jamais un fichier entier : fonctions modifiées, sélecteurs CSS, blocs HTML ciblés, avec l'emplacement exact. Si tu édites directement (Claude Code), fais des `Edit` ciblés.
- **Ne lis ni ne modifie jamais `data.js`** (464 objets). Pas de faux objets de test sauf demande.
- Ne supprime aucun code existant sans le signaler.
- Information clé manquante → pose une seule question courte avant de coder.

## Architecture (fichiers séparés, jamais fusionnés)
`index.html`, `style.css`, `script.js`, `data.js`, `manifest.json` + `sw.js`. Clicker : `clicker/` (html, css, core, passives, spells).

## Règles métier
- Raretés en MAJUSCULES : `C PC R TR L A` ; taux C40 PC25 R20 TR8 L5 A2.
- Chemins absolus SW/manifest/URL : préfixe du dépôt GitHub Pages. **Préfixe à confirmer** (`/mcc/arcane_vault/` historique vs `/coffre_des_arcanes/` actuel) — voir MEMOIRE §0.
- Fragments : 5 = 1 clé ; pont clicker→coffre idempotent (`earned − clickerClaimed`).
- Ne jamais fabriquer de code de profil/triche ; passer par l'outil MJ (8416).

## Pièges
Pas de `</script>` dans un commentaire JS ; pas de backticks imbriqués ; éléments `position:fixed` flottants directement sous `<body>` ; sons uniquement sur action utilisateur.

## Vérification
Après modif JS : `node --check` sur le fichier ; tests de fumée Node avec DOM stubbé pour la logique pure.
